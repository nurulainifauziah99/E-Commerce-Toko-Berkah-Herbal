
<?php $koneksi = new mysqli ("localhost","root","","tokoherbal"); ?>
<h1>
<b>Selamat Datang Administrator</b>
</h6>
<pre><?php print_r($_SESSION); ?></pre>